/*
	Header file for the grass model

	Author(s): Corneliu Dabija
*/

#pragma once

#include <vector>
#include <glm/glm.hpp>
#include <GL/glew.h>
#include "Ground.h"

class GrassModel : public Model {

public:
	GrassModel( Ground * ground, int iX = -5, int iZ = -5, int iDiffX = 10, int iDiffZ = 10 );
	virtual ~GrassModel();
	virtual void update( float dt );
	virtual void draw();

private:
	glm::mat4 getRotationMatrix( float fAngle, glm::vec3 v );
	GLuint vertexBufferID;
	unsigned int vertexArrayID;
	float fRotHeadStart;
};

struct Vertex {
	glm::vec3 position;
	glm::vec3 normal;
	glm::vec3 color;
};