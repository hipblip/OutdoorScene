//
// COMP 371 Assignment Framework
//
// Created by Nicolas Bergeron on 8/7/14.
// Modified by RJ Brack on 2014-Aug-17
//
// Copyright (c) 2014 Concordia University. All rights reserved.
//
// Author(s): RJ Brack

#include "CubeModel.h"
#include "Renderer.h"

// Include GLEW - OpenGL Extension Wrangler
#include <GL/glew.h>

CubeModel::CubeModel(Model* parent, glm::vec3 size) : Model(parent)
{
    skyboxTexture = loadBMP_custom( "Models/skybox.bmp" );

	setShaderToUse(ShaderToUse::SKYBOX);

	glm::vec3 halfSize = size * 0.5f;
	
	static const GLfloat vertexBufferData[] =
    {
        -halfSize.x, -halfSize.y, -halfSize.z,  //left
        -halfSize.x, -halfSize.y,  halfSize.z,
        -halfSize.x,  halfSize.y,  halfSize.z,

        -halfSize.x, -halfSize.y, -halfSize.z,
        -halfSize.x,  halfSize.y,  halfSize.z,
        -halfSize.x,  halfSize.y, -halfSize.z,

         halfSize.x,  halfSize.y, -halfSize.z,  // front
        -halfSize.x, -halfSize.y, -halfSize.z,
        -halfSize.x,  halfSize.y, -halfSize.z,

         halfSize.x,  halfSize.y, -halfSize.z,
         halfSize.x, -halfSize.y, -halfSize.z,
        -halfSize.x, -halfSize.y, -halfSize.z,

         halfSize.x, -halfSize.y,  halfSize.z,  // bottom
        -halfSize.x, -halfSize.y, -halfSize.z,
         halfSize.x, -halfSize.y, -halfSize.z,

         halfSize.x, -halfSize.y,  halfSize.z,
        -halfSize.x, -halfSize.y,  halfSize.z,
        -halfSize.x, -halfSize.y, -halfSize.z,

        -halfSize.x,  halfSize.y,  halfSize.z,  // back
        -halfSize.x, -halfSize.y,  halfSize.z,
         halfSize.x, -halfSize.y,  halfSize.z,

         halfSize.x,  halfSize.y,  halfSize.z,
        -halfSize.x,  halfSize.y,  halfSize.z,
         halfSize.x, -halfSize.y,  halfSize.z,

         halfSize.x,  halfSize.y,  halfSize.z,  // right
         halfSize.x, -halfSize.y, -halfSize.z,
         halfSize.x,  halfSize.y, -halfSize.z,

         halfSize.x, -halfSize.y, -halfSize.z,
         halfSize.x,  halfSize.y,  halfSize.z,
         halfSize.x, -halfSize.y,  halfSize.z,

         halfSize.x,  halfSize.y,  halfSize.z,  // top
         halfSize.x,  halfSize.y, -halfSize.z,
        -halfSize.x,  halfSize.y, -halfSize.z,

         halfSize.x,  halfSize.y,  halfSize.z,
        -halfSize.x,  halfSize.y, -halfSize.z,
        -halfSize.x,  halfSize.y,  halfSize.z,
    };

    static const GLfloat uvBufferData[] =
    {
        0.25, 0.00, // left
        0.00, 0.00,
        0.00, 0.50,

        0.25, 0.00,
        0.00, 0.50,
        0.25, 0.50,

        0.50, 0.50, // front
        0.25, 0.00,
        0.25, 0.50,

        0.50, 0.50,
        0.50, 0.00,
        0.25, 0.00,

        0.00, 0.50, // bottom
        0.00, 1.00,
        0.25, 1.00,

        0.00, 0.50,
        0.25, 1.00,
        0.25, 0.50,

        1.00, 0.50, // back
        1.00, 0.00,
        0.75, 0.00,

        0.75, 0.50,
        1.00, 0.50,
        0.75, 0.00,
        
        0.75, 0.50, // right
        0.50, 0.00,
        0.50, 0.50,

        0.50, 0.00,
        0.75, 0.50,
        0.75, 0.00,

        0.50, 1.00, // top
        0.50, 0.50,
        0.25, 0.50,

        0.50, 1.00,
        0.25, 0.50,
        0.25, 1.00,
    };

    glGenBuffers( 1, &vertexBuffer );
	glBindBuffer( GL_ARRAY_BUFFER, vertexBuffer );
	glBufferData( GL_ARRAY_BUFFER, sizeof( vertexBufferData ), vertexBufferData, GL_STATIC_DRAW );

    glGenBuffers( 1, &uvBuffer );
	glBindBuffer( GL_ARRAY_BUFFER, uvBuffer );
	glBufferData( GL_ARRAY_BUFFER, sizeof( uvBufferData ), uvBufferData, GL_STATIC_DRAW );
}

CubeModel::~CubeModel()
{
	glDeleteBuffers( 1, &uvBuffer );
	glDeleteBuffers( 1, &vertexBuffer );
}

void CubeModel::update(float dt)
{
}

void CubeModel::draw()
{
    GLuint skyboxTextureID = glGetUniformLocation( Renderer::getShader(), "textureSampler" );
    glUniform1i( skyboxTextureID, 0 );
	
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, skyboxTexture);

	// 1st attribute buffer : vertex Positions
	glEnableVertexAttribArray(0);
	glBindBuffer(GL_ARRAY_BUFFER, vertexBuffer);
	glVertexAttribPointer( 0, 3, GL_FLOAT, GL_FALSE, 0, (void*)0 );

    // 2nd attribute buffer : UV Coordinates
    glEnableVertexAttribArray(1);
	glBindBuffer(GL_ARRAY_BUFFER, uvBuffer);
	glVertexAttribPointer( 1, 2, GL_FLOAT, GL_FALSE, 0, (void*)0 );

	// Draw the triangles !
	glDrawArrays(GL_TRIANGLES, 0, 36); // 36 vertices: 3 * 2 * 6 (3 per triangle, 2 triangles per face, 6 faces)

	glDisableVertexAttribArray(1);
	glDisableVertexAttribArray(0);
}

GLuint CubeModel::loadBMP_custom(const char * imagepath)
{
	printf("Reading image %s\n", imagepath);

	// Data read from the header of the BMP file
	unsigned char header[54];
	unsigned int dataPos;
	unsigned int imageSize;
	unsigned int width, height;
	// Actual RGB data
	unsigned char * data;

	// Open the file
	FILE * file = NULL;
	errno_t errorCode = fopen_s(&file, imagepath,"rb");
	if (errorCode != 0)							   
		{printf("%s could not be opened. Are you in the right directory ? Don't forget to read the FAQ !\n", imagepath); getchar(); return 0;}

	// Read the header, i.e. the 54 first bytes

	// If less than 54 bytes are read, problem
	if ( fread(header, 1, 54, file)!=54 ){ 
		printf("Not a correct BMP file\n");
		return 0;
	}
	// A BMP files always begins with "BM"
	if ( header[0]!='B' || header[1]!='M' ){
		printf("Not a correct BMP file\n");
		return 0;
	}
	// Make sure this is a 24bpp file
	if ( *(int*)&(header[0x1E])!=0  )         {printf("Not a correct BMP file\n");    return 0;}
	if ( *(int*)&(header[0x1C])!=24 )         {printf("Not a correct BMP file\n");    return 0;}

	// Read the information about the image
	dataPos    = *(int*)&(header[0x0A]);
	imageSize  = *(int*)&(header[0x22]);
	width      = *(int*)&(header[0x12]);
	height     = *(int*)&(header[0x16]);

	// Some BMP files are misformatted, guess missing information
	if (imageSize==0)    imageSize=width*height*3; // 3 : one byte for each Red, Green and Blue component
	if (dataPos==0)      dataPos=54; // The BMP header is done that way

	// Create a buffer
	data = new unsigned char [imageSize];

	// Read the actual data from the file into the buffer
	fread(data,1,imageSize,file);

	// Everything is in memory now, the file wan be closed
	fclose (file);

	// Create one OpenGL texture
	GLuint textureID;
	glGenTextures(1, &textureID);
	
	// "Bind" the newly created texture : all future texture functions will modify this texture
	glBindTexture(GL_TEXTURE_2D, textureID);

	// Give the image to OpenGL
	glTexImage2D(GL_TEXTURE_2D, 0,GL_RGB, width, height, 0, GL_BGR, GL_UNSIGNED_BYTE, data);

	// OpenGL has now copied the data. Free our own version
	delete [] data;

	// Poor filtering, or ...
	//glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	//glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST); 

	// ... nice trilinear filtering.
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR); 
	glGenerateMipmap(GL_TEXTURE_2D);

	// Return the ID of the texture we just created
	return textureID;
}
