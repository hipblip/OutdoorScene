//
// COMP 371 Assignment Framework
//
// Created by Nicolas Bergeron on 8/7/14.
// Modified by RJ Brack on 2014-Aug-17
//
// Copyright (c) 2014 Concordia University. All rights reserved.
//
// Author(s): RJ Brack

#pragma once

#include "Model.h"


class CubeModel : public Model
{
public:
	// @TODO 4 - It could be a good idea to allow passing a parent model in the constructor
	CubeModel(Model* parent=NULL, glm::vec3 size = glm::vec3(1.0f, 1.0f, 1.0f));
	virtual ~CubeModel();

	virtual void update(float dt);
	virtual void draw();
    GLuint loadBMP_custom( const char * );

private:
    GLuint skyboxTexture;
    GLuint uvBuffer;
    GLuint vertexBuffer;
};
