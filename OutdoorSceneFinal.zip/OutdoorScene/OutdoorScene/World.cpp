/*
	This class initializes all the scene objects, draws the world, and updates the world.

	Author(s): Samuel Desranleau, Daniel Miller, Angela Carriero
*/

#include "World.h"
#include "Ground.h"
#include "FirstPersonCamera.h"
#include "StaticCamera.h"
#include "Model.h"
#include "Lightning.h"
#include "CubeModel.h"
#include "GrassGenerator.h"
#include "GrassModel.h"
#include <vector>
#include <iostream>

std::vector<Model*> models;

/* Initialize all the models here in the constructor
 */
World::World() {

	skybox = new CubeModel(NULL, glm::vec3(1.f,1.f,1.f));
	skybox->setScaling(glm::vec3(100.f, 100.f, 100.f));
	addModel(skybox);

	terrain = new Ground();
	cameras.push_back(new FirstPersonCamera(glm::vec3(5,30,5), terrain));
	cameras.push_back(new StaticCamera(glm::vec3(10,50,10), glm::vec3(0,20,0), glm::vec3(0,1,0), terrain));
	models.push_back(terrain);
	currentCamera = 0;

	isFire = false;
	
	rain = new RainEffect(cameras[currentCamera]);
	fire = new FireEffect(cameras[currentCamera]);
	fireSmoke = new FireSmokeEffect(cameras[currentCamera]);

	GrassGenerator gg( terrain );
	vector<Model*> grass = gg.getGrass();

	for( vector<Model *>::iterator it = grass.begin(); it != grass.end(); ++it ) {
		addModel( * it );
	}

	string houseFilePath = "Models/house/house.obj";
	house = new OBJLoader(&houseFilePath[0]);
	house->setPosition(glm::vec3(5,30,5));

	stormOn = false;
	singleLightningOn = false;
	lightningOnTime = 0;
	lightningOffTime = 0;
	lightningNextWaitTime = rand()%10;
	colorIndex = 0;
	lightningColor = glm::vec3(1,1,1);
	staticCamera = true;
}

World::~World() {
	for (std::vector<Model*>::iterator it = models.begin(); it < models.end(); ++it) {
		//delete *it;
	}

	for (vector<Lightning*>::iterator it = mLightning.begin(); it < mLightning.end(); ++it)
	{
		delete *it;
	}

	for (vector<Camera*>::iterator it = cameras.begin(); it < cameras.end(); ++it)
	{
		delete *it;
	}

	cameras.clear();
	models.clear();
	mLightning.clear();
}

// float dt is the frame time
void World::update(float dt) {

	cameras[currentCamera]->Update(dt);

	// Switches between First person and "static" camera
	if (glfwGetKey(EventManager::GetWindow(), GLFW_KEY_1) == GLFW_PRESS) {
		currentCamera = 0;
	} else if (glfwGetKey(EventManager::GetWindow(), GLFW_KEY_2) == GLFW_PRESS) {
		currentCamera = 1;
	}

	// Turns on the storm
	if (glfwGetKey(EventManager::GetWindow(), GLFW_KEY_L ) == GLFW_PRESS)
	{
		stormOn = true;
		//Clear all lightning no matter what
		for (vector<Lightning*>::iterator it = mLightning.begin(); it < mLightning.end(); ++it)
		{
			delete *it;
		}
		mLightning.clear();
	}

	// Turns off the storm
	else if (glfwGetKey(EventManager::GetWindow(), GLFW_KEY_K ) == GLFW_PRESS)
	{
		stormOn = false;
		//Clear all lightning no matter what
		for (vector<Lightning*>::iterator it = mLightning.begin(); it < mLightning.end(); ++it)
		{
			delete *it;
		}
		mLightning.clear();
	}

	// Changes teh Lightning's color
	if (glfwGetKey(EventManager::GetWindow(), GLFW_KEY_P ) == GLFW_PRESS)
	{
		if (colorIndex>4)
		{
			colorIndex = 0;
		}
		switch (colorIndex++)
		{
		case 0:
			lightningColor = glm::vec3(1,1,1);
			break;
		case 1:
			lightningColor = glm::vec3(1,0,0);
			break;
		case 2:
			lightningColor = glm::vec3(1,.75f,0);
			break;
		case 3:
			lightningColor = glm::vec3(0,0.5f,1);
			break;
		case 4:
			lightningColor = glm::vec3(1,0,1);
			break;
		default:
			break;
		}
	}

	
	if (stormOn)
	{
		if (singleLightningOn)
		{
			lightningOnTime+=dt;
		}
		else
		{
			lightningOffTime+=dt;
		}
	}

	if (glfwGetKey(EventManager::GetWindow(), GLFW_KEY_F) == GLFW_PRESS){
		isFire = true;
	}
	if (glfwGetKey(EventManager::GetWindow(), GLFW_KEY_G) == GLFW_PRESS){
		isFire = false;
	}

	//Update the models
	for (std::vector<Model*>::iterator it = models.begin(); it < models.end(); ++it)
	{
		(*it)->update(dt);
	}


	if(isFire){
		fire->Update(dt, EventManager::wind());
		fireSmoke->Update(dt, EventManager::wind());
	}
	if(stormOn){
		rain->Update(dt, EventManager::wind());
	}

}

void World::draw() {
	// Get camera information to send to the individual shaders
	glm::mat4 viewMatrix = cameras[currentCamera]->GetViewMatrix();
	glm::mat4 projMatrix = cameras[currentCamera]->GetProjectionMatrix();
	glm::mat4 viewProjMatrix = cameras[currentCamera]->GetViewProjectionMatrix();

	bool bWind = EventManager::wind();

	GLuint oldShader = Renderer::getShaderVectorPosition();

	// Loop throught he models, get its transform, assign them to their respective variables in the shader, and draw the model
	for (std::vector<Model*>::iterator it = models.begin(); it < models.end(); ++it)  {	
		Renderer::setShader((GLuint)(*it)->getShaderToUse());
		glUseProgram(Renderer::getShader());

		if ((*it)->getShaderToUse() == ShaderToUse::GROUND_SHADER) {
			GLuint viewID = glGetUniformLocation(Renderer::getShader(), "viewMatrix");
			GLuint projID = glGetUniformLocation(Renderer::getShader(), "projectionMatrix");

			glUniformMatrix4fv(viewID, 1, GL_FALSE, &viewMatrix[0][0]);
			glUniformMatrix4fv(projID, 1, GL_FALSE, &projMatrix[0][0]);

		} else if ((*it)->getShaderToUse() == ShaderToUse::SKYBOX) {
			GLuint viewProjID = glGetUniformLocation(Renderer::getShader(), "ViewProjectonTransform");
			GLuint WorldMatrixLocation = glGetUniformLocation(Renderer::getShader(), "WorldTransform"); 
			glUniformMatrix4fv(WorldMatrixLocation, 1, GL_FALSE, &(*it)->getWorldMatrix()[0][0]);
			
			glUniformMatrix4fv(viewProjID, 1, GL_FALSE, &viewProjMatrix[0][0]);

		} else if ((*it)->getShaderToUse() == ShaderToUse::SOLID_COLOR_SHADER) {
			GLuint viewProjID = glGetUniformLocation(Renderer::getShader(), "ViewProjectonTransform");
			GLuint worldID = glGetUniformLocation(Renderer::getShader(), "WorldTransform");

			glUniformMatrix4fv(viewProjID, 1, GL_FALSE, &viewProjMatrix[0][0]);
			glUniformMatrix4fv(worldID, 1, GL_FALSE, &(*it)->getWorldMatrix()[0][0]);

			(*it)->wind( bWind );
			(*it)->update( 1 );
		}


		(*it)->draw();
	}

	Renderer::setShader((GLuint)ShaderToUse::IMPORTED_MODEL_SHADER);
	glUseProgram(Renderer::getShader());

	GLuint viewID = glGetUniformLocation(Renderer::getShader(), "ViewTransform");
	GLuint projID = glGetUniformLocation(Renderer::getShader(), "ProjectionTransform");

	glUniformMatrix4fv(viewID, 1, GL_FALSE, &viewMatrix[0][0]);
	glUniformMatrix4fv(projID, 1, GL_FALSE, &projMatrix[0][0]);

	house->draw();

	if (stormOn)
	{
		if (lightningOnTime > .25f)
		{
			lightningOnTime = 0;
			singleLightningOn = false;
			for (vector<Lightning*>::iterator it = mLightning.begin(); it < mLightning.end(); ++it)
			{
				delete *it;
			}
			mLightning.clear();
			terrain->resetLightConstants();
		}
		else if (lightningOffTime > lightningNextWaitTime)
		{
			lightningOffTime = 0;
			singleLightningOn = true;
			lightningNextWaitTime = rand() % 7;	

			int scalar = rand()%50+10;

			glm::vec3 look = glm::vec3(cameras[currentCamera]->GetLookAt());
			glm::vec3 pos = cameras[currentCamera]->GetPosition();

			glm::vec3 start = pos + glm::vec3(look.x*scalar, look.y*scalar, look.z*scalar);

			start.y = 50;

			generateLightning(start, glm::vec3(start.x,0, start.z), 6, 10, lightningColor, look);
			terrain->setLightColor(lightningColor);
			terrain->setKa(10);
		}

	}

	for (vector<Lightning*>::iterator it = mLightning.begin(); it < mLightning.end(); ++it)
	{
		Renderer::setShader((GLuint)(*it)->getShaderToUse());

		glUseProgram(Renderer::getShader());

		GLuint viewProjID = glGetUniformLocation(Renderer::getShader(), "ViewProjectonTransform");
		GLuint worldID = glGetUniformLocation(Renderer::getShader(), "WorldTransform");

		glUniformMatrix4fv(viewProjID, 1, GL_FALSE, &viewProjMatrix[0][0]);
		glUniformMatrix4fv(worldID, 1, GL_FALSE, &(*it)->getWorldMatrix()[0][0]);

		// Draw model
		(*it)->draw();
	}	

	if(stormOn || isFire){
		Renderer::setShader((GLuint)ShaderToUse::SHADER_PARTICLE);
		glUseProgram(Renderer::getShader());
		if(stormOn){
			rain->Draw();
		}
		if(isFire){
			fire->Draw();
			fireSmoke->Draw();
		}
	}


}

void World::addModel(Model* toAdd) {
	models.push_back(toAdd);
}

//Recursively creat lightning bolts
void World::generateLightning(glm::vec3 &start, glm::vec3 &end, int noise, float width, glm::vec3 color, glm::vec3 direction)
{
	Lightning* lightning = new Lightning(start, end, noise, width, color, direction);
	mLightning.push_back(lightning);
	//vector<Lightning*> allLightning = Lightning::getAllBranches();
	int itVal = 0;
	std::vector<glm::vec3> points = lightning->getPoints();
    for (vector<glm::vec3>::iterator it = points.begin(); itVal < 50; itVal++, ++it)
    {
    	if(rand()%10==0 &&Lightning::getAllBranches().size() < 20)
    	{
    		generateLightning(*it, end, noise, width/2, color, direction);
    	}
    }
}