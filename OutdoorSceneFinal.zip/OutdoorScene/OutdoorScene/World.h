/*
	Header class for world.cpp.

	Modifications done by: Samuel Desranleau, Daniel Miller, Angela Carriero
*/

#pragma once

#define GLEW_STATIC
#include <GL/glew.h>
#include <vector>

#include <GLM/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/common.hpp>

#include <GLFW/glfw3.h>

#include <vector>

#include "Renderer.h"
#include "Camera.h"
#include "Model.h"
#include "Ground.h"
#include "Lightning.h"
#include "FireSmokeEffect.h"
#include "FireEffect.h"
#include "RainEffect.h"
#include "CubeModel.h"

class Model;

class World {
public:
	World();
	~World();

	void update(float dt);
	void draw();

	void addModel(Model* toAdd);

	Camera* getCamera() { return cameras[currentCamera]; };

	//is lightning flashing?
	bool stormOn;
	//is lightning currently visible??
	bool singleLightningOn;
	float lightningOnTime;
	float lightningOffTime;
	float lightningNextWaitTime;
	int colorIndex;
	glm::vec3 lightningColor;
	bool staticCamera;

	void generateLightning(glm::vec3 &start, glm::vec3 &end, int noise, float width, glm::vec3 color, glm::vec3 direction);

private:
	std::vector<Model*> models;
	std::vector<Camera*> cameras;
	std::vector<Lightning*> mLightning;

	FireSmokeEffect* fireSmoke;
	FireEffect* fire;
	RainEffect* rain;
	CubeModel* skybox;

	int currentCamera;

	GLuint vertexBufferID;
	GLuint vertexArrayID;
	unsigned int numVertices;

	bool raining;
	bool isFire;

	Ground* terrain;
	OBJLoader* house;
};