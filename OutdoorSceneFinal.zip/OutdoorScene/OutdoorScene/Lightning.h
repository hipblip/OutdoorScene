//DANIEL MILLER

#pragma once
#include <vector>
#include "Model.h"
#include <glm/glm.hpp>

class Lightning : public Model
{
public:
	Lightning(glm::vec3 &start, glm::vec3 &end, int noise, float width, glm::vec3 color, glm::vec3 direction);
	~Lightning(void);

	void setStart(glm::vec3 &v);
	void setEnd(glm::vec3 &v);

	glm::vec3 getStart();
	glm::vec3 getEnd();

	//We will need to get all points in order to create branches
	std::vector<glm::vec3> getPoints();
	

	void setColor(glm::vec3 v);

	void update(float dt);
	void draw();

	//Recursively get all branches
	static std::vector<Lightning*> getAllBranches();
	void tryToBranch(glm::vec3 &start, glm::vec3 &end);

private:
	//direction camera is facing
	glm::vec3 direction;
	int noise;
	float width;
	glm::vec3 color;
	glm::vec3 startPt, endPt;
	
	unsigned int mVertexArrayID;
	unsigned int mVertexBufferID;
	static std::vector<Lightning*> allBranches;
	static int branchCount;

	struct Vertex
	{
		glm::vec3 position;
		glm::vec3 rotation;
		glm::vec3 color;
	};

	//start and end pts are special cases, do not belong in this list since we will not be branching from extremes
	std::vector<glm::vec3> points;


};


