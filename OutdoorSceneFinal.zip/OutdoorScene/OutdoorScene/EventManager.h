#pragma once

struct GLFWwindow;

class EventManager {
public:
	static GLFWwindow* GetWindow();
	static void setUp();
	static void terminateProgram();
	static bool exitLoop();
	static void update();

	static float GetFrameTime();
	static float GetMouseMotionX();
	static float GetMouseMotionY();

	static void DisableMouseCursor();
	static void EnableMouseCursor();

	static bool wind();

private:
	
	static GLFWwindow* window;
	static int windowWidth;
	static int windowHeight;

	static float sMouseDeltaX;
	static float sMouseDeltaY;
	static float sLastMousePositionX;
	static float sLastMousePositionY;

	static float sFrameTime;
	static float sLastFrameTime;
};