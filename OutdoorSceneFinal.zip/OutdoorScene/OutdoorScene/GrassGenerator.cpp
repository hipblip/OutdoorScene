/*
	This class generates the grass models.

	Author(s): Corneliu Dabija
*/

#pragma once

#include "GrassGenerator.h"
#include "Ground.h"
#include<ctime>

GrassGenerator::GrassGenerator( Ground * ground ) {
	srand(time(0));
	gro = ground;
}

GrassGenerator::~GrassGenerator() {}

vector<Model *> GrassGenerator::getGrass() {
	vector<Model *> grass;
	for( int j = 0; j < 1000; j++ ) {
		grass.push_back( new GrassModel( gro, -5, -5, 10, 10 ) );
	}
	return grass;
}