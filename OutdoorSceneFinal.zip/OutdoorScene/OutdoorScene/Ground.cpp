/*

This class uses a height map stored in a grey scaled bitmap file to create the terrain for the scene.  
Indexed drawing is used to alter the heights at the vertices of the terrain.

Author(s): Samuel Desranleau, Daniel Miller

*/

#include "Ground.h"
#include <FreeImage.h>


// Initializes the scale of the map and loads the textures and height map.  
// Sets the lighting coefficients to their default values.
Ground::Ground() {
	hmScale = glm::vec3(100.f, 20.f, 100.f);
	setPosition(glm::vec3(getPosition().x, (getPosition().y), getPosition().z));
	setShaderToUse(ShaderToUse::GROUND_SHADER);
	loadGroundTexture("Models/sandGrass.jpg", "Models/rock1.jpg");
	loadHeightMap("Models/test1.bmp");
	scaledV = vector<vector<glm::vec3>>(hmRows, vector<glm::vec3>(hmCols));
	scaledVertices();

	// Material Coefficients
	 ka = 5.f;
     kd = .9f;
     ks = 0.0f;
     n = 1.f;
    
     lightColor = glm::vec3(1.f, 1.f, 1.f);
     lightKc = 0.0f;
     lightKl = 0.0f;
     lightKq = 0.02f;
     lightPosition = glm::vec3(0.f, 50.f, 0.f);
}

// Destroys Buffer data
Ground::~Ground() {
	glDeleteVertexArrays(1, &vertexArrayID);
	glDeleteBuffers(1, &hmdataVertexBufferID);
	glDeleteBuffers(1, &indexVertexBufferID);
	glDeleteTextures(1, &textureID);
	glDeleteSamplers(1, &samplerID);
}

/*
	Loads a heightmap from a grey scaled image which must have square dimensions.

	@param the path to the file
	@return whether the file was correctly loaded or not
*/
bool Ground::loadHeightMap(string path) {

	FREE_IMAGE_FORMAT fif = FIF_UNKNOWN;
	FIBITMAP* dib(0);

	fif = FreeImage_GetFileType(path.c_str(), 0);
	if (fif == FIF_UNKNOWN) {
		fif = FreeImage_GetFIFFromFilename(path.c_str());
	}

	if (fif == FIF_UNKNOWN) {
		std::cout << "Unknown Filetype\n";
		return false;
	}

	if (FreeImage_FIFSupportsReading(fif)) {
		dib = FreeImage_Load(fif, path.c_str());
	}

	if (!dib) {
		std::cout << "Unable to load height map\n";
		return false;
	}

	BYTE* dataPointer = FreeImage_GetBits(dib);
	hmRows = FreeImage_GetHeight(dib);
	hmCols = FreeImage_GetWidth(dib);

	// How much to increase data pointer to get to next pixel data
	unsigned int ptr_inc = FreeImage_GetBPP(dib) == 24 ? 3 : 1;

	// Length of one row in data
	unsigned int row_step = ptr_inc * hmCols;

	glGenBuffers(1, &hmdataVertexBufferID);

	vector<vector<glm::vec2>> UVcoordinates(hmRows, vector<glm::vec2>(hmCols)); 
	vertices = vector<vector<glm::vec3>>(hmRows, vector<glm::vec3>(hmCols));

	float textureU = float(hmCols * 0.1);
	float textureV = float(hmRows * 0.1);

	// Calculate vertex and texture data from the value of the color in the height map
	for (int i = 0; i < hmRows; i++) {
		for (int j = 0; j < hmCols; j++) {
			float x = float(j) / float(hmCols - 1);
			float z = float(i) / float(hmRows - 1);
			float y = float(*(dataPointer + row_step * i + j * ptr_inc)) / 255.f;
			vertices[i][j] = glm::vec3(-.5 + x, y, -.5 + z);
			UVcoordinates[i][j] = glm::vec2(textureU * x, textureV * z);
			//scaledHeight.insert(std::pair<std::pair<float, float>, float>(std::pair<float, float>(x, z), y));
		}
	}
	
	// Calculate the normals by getting the normals of both triangles in a quad and storing them in a 3 dimensional vector
	vector<vector<glm::vec3>> triangleNormals[2]; // Every quad has 2 triangles
	for (int i = 0; i < 2; i++) {
		triangleNormals[i] = vector<vector<glm::vec3>>(hmRows - 1, vector<glm::vec3>(hmCols - 1));
	}

	// iterate through every quad and calculate the normals
	for (int i = 0; i < hmRows - 1; i++){
		for (int j = 0; j < hmCols - 1; j++) {
			glm::vec3 triangle0[] = {vertices[i][j], vertices[i+1][j], vertices[i+1][j+1]};
			glm::vec3 triangle1[] = {vertices[i+1][j+1], vertices[i][j+1], vertices[i][j]};
			glm::vec3 triangle0Norm = glm::cross(triangle0[0] - triangle0[1], triangle0[1] - triangle0[2]);
			glm::vec3 triangle1Norm = glm::cross(triangle1[0] - triangle1[1], triangle1[1] - triangle1[2]);
			triangleNormals[0][i][j] = glm::normalize(triangle0Norm);
			triangleNormals[1][i][j] = glm::normalize(triangle1Norm);
		}
	}

	// Calculate the normal of every vertex by taking the average of each adjacent triangle's normal
	vector<vector<glm::vec3>> vertexNormals = vector<vector<glm::vec3>>(hmRows, vector<glm::vec3>(hmCols));

	for (int i = 0; i < hmRows; i++) {
		for (int j = 0; j < hmCols; j++) {

			glm::vec3 norm(0,0,0);
			
			if (i != 0 && j != 0) {
				for(int	k = 0; k < 2; k++) {
					norm += triangleNormals[k][i-1][j-1];
				}
			}
			if (i != (hmRows - 1) && j != (hmCols - 1)) {
				for (int k = 0; k < 2; k++) {
					norm += triangleNormals[k][i][j];
				}
			}
			if (i != 0 && j != (hmCols - 1)) {
				norm += triangleNormals[0][i-1][j];
			}
			if (i != (hmRows - 1) && j != 0 ) {
				norm += triangleNormals[1][i][j-1];
			}

			norm = glm::normalize(norm);

			vertexNormals[i][j] = norm;
		}
	}

	// Create the buffer for the indexed drawing
	glGenBuffers(1, &hmdataVertexBufferID);
	data.reserve(hmRows * hmCols * (2 * sizeof(glm::vec3) + sizeof(glm::vec2)));
	dataSize = hmRows * hmCols * (2 * sizeof(glm::vec3) + sizeof(glm::vec2));
	currentDataSize = 0;

	glGenBuffers(1, &hmdataVertexBufferID);

	for (int i = 0; i < hmRows; i++) {
		for (int j = 0; j < hmCols; j++) {
			addData(&vertices[i][j], sizeof(glm::vec3));
			addData(&UVcoordinates[i][j], sizeof(glm::vec2));
			addData(&vertexNormals[i][j], sizeof(glm::vec3));
		}
	}

	glGenBuffers(1, &indexVertexBufferID);
	indexSize = 0;
	currentIndexSize = 0;

	int restartIndex = hmRows * hmCols;
	
	for (int i = 0; i < hmRows - 1; i++) {
		for (int j = 0; j < hmCols; j++) {
			for (int k = 0; k < 2; k++) {
				int row = i + (1 - k);
				int index = row * hmCols + j;
				addIndexData(&index, sizeof(int));
			}
		}
		addIndexData(&restartIndex, sizeof(int));
	}
	
	return true;
}

void Ground::scaledVertices() {
	for (int i = 0; i < hmRows; i++) {
		for (int j = 0; j < hmCols; j++) {

			float x = vertices[i][j].x * hmScale.x;
			float y = vertices[i][j].y * hmScale.y;
			float z = vertices[i][j].z * hmScale.z;
			scaledV[i][j] = (glm::vec3(x,y,z));

			scaledHeight.insert(std::pair<std::pair<int, int>, int>(std::pair<int, int>((int)x, (int)z), (int)y));
		}
	}
	
}

/*
	Returns the height of the terrain at a certain coordinate
	@param the x and z coordinates
	@return the y coordinate corresponding to the x and z coordinates provided
*/
float Ground::getHeight(float x, float z) {

	int ex = (int)x;
	int zed = (int)z;

	float height = 0;
	for (int i = 0; i < hmRows; i++) {
		for (int j = 0; j < hmCols; j++) {			
			if ((int)scaledV[i][j].x == ex && (int)scaledV[i][j].z == zed) {
				// Once scaling is done, finding the height at an exact position is difficult, therefore the given coordinates are converted to integers and
				//the average of the heights around the given coordinates is taken which gives a rough estimate of the actual height.
				height = (scaledV[i][j].y + scaledV[i+1][j].y + scaledV[i-1][j].y + scaledV[i][j+1].y + scaledV[i][j-1].y + scaledV[i+1][j+1].y +
							scaledV[i-1][j-1].y + scaledV[i+1][j-1].y + scaledV[i-1][j+1].y + scaledV[i+2][j].y + scaledV[i-2][j].y +
							scaledV[i][j+2].y + scaledV[i][j-2].y + scaledV[i+2][j+2].y + scaledV[i-2][j-2].y + scaledV[i+2][j-2].y +
							scaledV[i-2][j+2].y) / 17;
			}
		}
	}

	return height;
}

/*
	Sets the scale of the map
	@param the desired scale
	@return void
*/
void Ground::setHmScale(glm::vec3 scale) {
	hmScale = glm::vec3(scale);
}

// Stores data to be added to the index buffer
void Ground::addIndexData(void* ptr, GLuint dataSize) {
	iData.insert(iData.end(), (BYTE*)ptr, (BYTE*) ptr + dataSize);
	currentIndexSize += dataSize;
}

// Stores data to be added to the vertex buffer
void Ground::addData(void* ptr, GLuint dataSize) {
	data.insert(data.end(), (BYTE*) ptr, (BYTE*) ptr + dataSize);
	currentDataSize += dataSize;
}

/*
	Loads a texture froma file to be applied to the terrain
	@param the path to the texture file
	@return whether or not the file was loaded correctly
*/
bool Ground::loadGroundTexture(string path, string path2) {
	FREE_IMAGE_FORMAT fif = FIF_UNKNOWN;
	FREE_IMAGE_FORMAT fif2 = FIF_UNKNOWN;

	//FIBITMAP* texture3(0);
	FIBITMAP* texture2(0);
	FIBITMAP* texture(0);
	fif = FreeImage_GetFileType(path.c_str(), 0);
	fif2 = FreeImage_GetFileType(path2.c_str(), 0);



	if (fif == FIF_UNKNOWN) { // Unknown file type
		fif = FreeImage_GetFIFFromFilename(path.c_str());
	}
	if (fif2 == FIF_UNKNOWN) { // Unknown file type
		fif2 = FreeImage_GetFIFFromFilename(path2.c_str());
	}


	if (fif == FIF_UNKNOWN || fif2 == FIF_UNKNOWN /*|| fif3 == FIF_UNKNOWN*/) { // Still unkown file type
		std::cout << "Unknown Filetype\n";
		return false;
	}

	if (FreeImage_FIFSupportsReading(fif)) { // is the file supported by free image?
		texture = FreeImage_Load(fif, path.c_str());
	}
	if (FreeImage_FIFSupportsReading(fif2)) { // is the file supported by free image?
		texture2 = FreeImage_Load(fif2, path2.c_str());
	}

	if (!texture || !texture2 /*|| !texture3*/) {
		std::cout << "This file type is not supported by FreeImage\n";
		return false;
	}

	BYTE* dataPointer = FreeImage_GetBits(texture);
	BYTE* dataPointer2 = FreeImage_GetBits(texture2);
	//BYTE* dataPointer3 = FreeImage_GetBits(texture3);

	textureWidth = FreeImage_GetWidth(texture);
	textureHeight = FreeImage_GetHeight(texture);
	textureBPP = FreeImage_GetBPP(texture);

	textureWidth2 = FreeImage_GetWidth(texture2);
	textureHeight2 = FreeImage_GetHeight(texture2);
	textureBPP2 = FreeImage_GetBPP(texture2);

	glGenTextures(1, &textureID2);
	glBindTexture(GL_TEXTURE_2D, textureID2);
	
	int format2 = textureBPP2 == 24 ? GL_BGR : textureBPP2 == 8 ? GL_LUMINANCE : 0;
	int internalFormat2 = textureBPP2 == 24 ? GL_BGR : GL_DEPTH_COMPONENT;
		
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, textureWidth2, textureHeight2, 0, format2, GL_UNSIGNED_BYTE, dataPointer2);

	glGenerateMipmap(GL_TEXTURE_2D);	

	FreeImage_Unload(texture2);

	glGenTextures(1, &textureID);
	glBindTexture(GL_TEXTURE_2D, textureID);
	
	int format = textureBPP == 24 ? GL_BGR : textureBPP == 8 ? GL_LUMINANCE : 0;
	int internalFormat = textureBPP == 24 ? GL_BGR : GL_DEPTH_COMPONENT;
		
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, textureWidth, textureHeight, 0, format, GL_UNSIGNED_BYTE, dataPointer);

	glGenerateMipmap(GL_TEXTURE_2D);	

	FreeImage_Unload(texture);

	glGenSamplers(1, &samplerID);

	texturePath = path;

	// Tri linear filtering
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR); 
	glGenerateMipmap(GL_TEXTURE_2D);

	return true;
}

// The ground shouldn't need any animations
void Ground::update(float dt) {
}

/* Draws the ground according to the height map provided
 * @param void
 * @return void
 */
void Ground::draw() {
	glm::mat4 view = glm::lookAt(glm::vec3(0, 30, 30), glm::vec3(0, 0, 0), glm::vec3(0.0f, 1.0f, 0.0f));
	glm::mat4 projection = glm::perspective(45.0f, 4.0f / 3.0f, 0.1f, 1000.0f);


	GLuint worldID = glGetUniformLocation(Renderer::getShader(), "worldMatrix");
	GLuint TextureID  = glGetUniformLocation(Renderer::getShader(), "myTextureSampler");
	GLuint TextureID2 = glGetUniformLocation(Renderer::getShader(), "Texture2");
	GLuint TextureID3 =  glGetUniformLocation(Renderer::getShader(), "Texture3");
	GLuint hmScaleID = glGetUniformLocation(Renderer::getShader(), "scaleMatrix");

	glm::mat4 scaleMat = glm::scale(glm::mat4(1.f), hmScale);

	glUniformMatrix4fv(worldID, 1, GL_FALSE, &getWorldMatrix()[0][0]);
	glUniformMatrix4fv(hmScaleID, 1, GL_FALSE, &scaleMat[0][0]);

	
	GLuint lightAttenuationID = glGetUniformLocation(Renderer::getShader(), "lightAttenuation");
	GLuint materialID = glGetUniformLocation(Renderer::getShader(), "materialCoefficients");
	GLuint lightColorID = glGetUniformLocation(Renderer::getShader(), "lightColor");
	GLuint lightPositionID = glGetUniformLocation(Renderer::getShader(), "lightVector");
	GLuint renderHeightID = glGetUniformLocation(Renderer::getShader(), "renderHeight");

	glUniform4f(materialID, ka, kd, ks, n);
	glUniform3f(lightPositionID, lightPosition.x, lightPosition.y, lightPosition.z);
	glUniform3f(lightColorID, lightColor.r, lightColor.g, lightColor.b);
	glUniform3f(lightAttenuationID, lightKc, lightKl, lightKq);

	glUniform1fv(renderHeightID, 1, &hmScale.y);

	// Send Grass Texture data
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, textureID);
	glUniform1i(TextureID, 0);

	// Send Rock Texture data
	glActiveTexture(GL_TEXTURE0 + 1);
	glBindTexture(GL_TEXTURE_2D, textureID2);
	glUniform1i(TextureID2, 1);

	// Send Vertex Array data and set primitive restart index
	glBindVertexArray(vertexArrayID);
	glEnable(GL_PRIMITIVE_RESTART);
	glPrimitiveRestartIndex(hmRows * hmCols);

	glGenVertexArrays(1, &vertexArrayID);
	glBindVertexArray(vertexArrayID);

	glBindBuffer(GL_ARRAY_BUFFER, hmdataVertexBufferID);
	glBufferData(GL_ARRAY_BUFFER, data.size(), &data[0], GL_STATIC_DRAW);

	glEnableVertexAttribArray(0);
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 2*sizeof(glm::vec3)+sizeof(glm::vec2), 0);
	// Texture coordinates
	glEnableVertexAttribArray(1);
	glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 2*sizeof(glm::vec3)+sizeof(glm::vec2), (void*)sizeof(glm::vec3));
	// Normal vectors
	glEnableVertexAttribArray(2);
	glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, 2*sizeof(glm::vec3)+sizeof(glm::vec2), (void*)(sizeof(glm::vec3)+sizeof(glm::vec2)));

	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, indexVertexBufferID);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, iData.size(), &iData[0], GL_STATIC_DRAW);
	
	int iNumIndices = (hmRows-1)*hmCols*2 + hmRows-1;
	glDrawElements(GL_TRIANGLE_STRIP, iNumIndices, GL_UNSIGNED_INT, 0);
}

/*
	This function is used to reset the light constants after the lightning has struck, or any other lighting changes is done.
	@param void
	@return void
*/
void Ground::resetLightConstants() {
	ka = 5.f;
	kd = .9f;
	ks = 0.0f;
	n = 1.f;
	
	lightColor = glm::vec3(1.f, 1.f, 1.f);
	lightKc = 0.0f;
	lightKl = 0.0f;
	lightKq = 0.02f;
	lightPosition = glm::vec3(0.f, 50.f, 0.f);
}

/*
	Sets the color of the light.  
	@param the color of the light stored in a 3 dimensional vector in RGB format
	@return void
*/
void Ground::setLightColor(glm::vec3 color)
{
	lightColor = color;
}

/*
	Sets the ambient coefficient for the lighting of the ground.
	@param the desired ambient light coefficient
	@return void
*/
void Ground::setKa(float f)
{
	ka = f;
}
