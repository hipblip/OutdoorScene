#include "World.h"
#include "Ground.h"
#include "FirstPersonCamera.h"
#include "Model.h"
#include <vector>
#include <iostream>

std::vector<Model*> models;

/* Initialize all the models here in the constructor
 */
World::World() {
	cameras.push_back(new FirstPersonCamera(glm::vec3(5,30,5)));
	currentCamera = 0;
}

World::~World() {
	for (std::vector<Model*>::iterator it = models.begin(); it < models.end(); ++it) {
		//delete *it;
	}

	models.clear();
}

// float dt is the frame time
void World::update(float dt) {
	cameras[currentCamera]->Update(dt);

	//Update the models
	for (std::vector<Model*>::iterator it = models.begin(); it < models.end(); ++it)
	{
		(*it)->update(dt);
	}
}

void World::draw() {

	// Get camera information to send to the individual shaders
	glm::mat4 viewMatrix = cameras[currentCamera]->GetViewMatrix();
	glm::mat4 projMatrix = cameras[currentCamera]->GetProjectionMatrix();
	glm::mat4 viewProjMatrix = cameras[currentCamera]->GetViewProjectionMatrix();
	
	// Loop throught he models, get its transform, assign them to their respective variables in the shader, and draw the model
	for (std::vector<Model*>::iterator it = models.begin(); it < models.end(); ++it)  {


		
		Renderer::setShader((GLuint)(*it)->getShaderToUse());
		glUseProgram(Renderer::getShader());

		if ((*it)->getShaderToUse() == ShaderToUse::GROUND_SHADER) {
			GLuint viewID = glGetUniformLocation(Renderer::getShader(), "viewMatrix");
			GLuint projID = glGetUniformLocation(Renderer::getShader(), "projectionMatrix");

			glUniformMatrix4fv(viewID, 1, GL_FALSE, &viewMatrix[0][0]);
			glUniformMatrix4fv(projID, 1, GL_FALSE, &projMatrix[0][0]);
		}

		(*it)->draw();
	}
}

void World::addModel(Model* toAdd) {
	models.push_back(toAdd);
}