#pragma once

#include <GLM/glm.hpp>
#include "OBJLoader.h"

	// Be sure they are all in the order their shaders are loaded into the vector, or every value is defined explicitly.
	enum class ShaderToUse {IMPORTED_MODEL_SHADER, SOLID_COLOR_SHADER, GROUND_SHADER};

class Model {
public:
	
 

	Model(Model *parent);
	Model();
	virtual ~Model();

	virtual void update(float dt) = 0;
	virtual void draw() = 0;

	void setPosition(glm::vec3 pos) { mPosition = pos; };
	void setScaling(glm::vec3 scale) { mScaling = scale; };
	void setRotationAxis(glm::vec3 axis) { mRotationAxis = axis; };
	void setRotationAngle(float angle) {mRotationAngle = angle; };

	glm::mat4 getWorldMatrix();

	virtual ShaderToUse getShaderToUse() { return shader; };

protected:
	void setShaderToUse(ShaderToUse shade) { shader = shade; };
	
private:
	glm::vec3 mPosition;
	glm::vec3 mScaling;
	glm::vec3 mRotationAxis;
	float     mRotationAngle;

	ShaderToUse shader;



	Model* parent;
	//OBJLoader* importedModel; // Only used if the model is imported
};