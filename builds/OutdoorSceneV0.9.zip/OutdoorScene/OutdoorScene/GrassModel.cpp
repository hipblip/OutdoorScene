/*
	This class generates a random number of blades of grass and animates them to simulate wind.

	Author(s): Corneliu Dabija
*/

#pragma once
#include <iostream>
#include <GL/glew.h>
#include <GLFW/glfw3.h>
#include <glm/gtc/matrix_transform.hpp>
#include "Model.h"
#include "GrassModel.h"
#include "Renderer.h"

using namespace std;

GrassModel::GrassModel( Ground * ground, int iX, int iZ, int iDiffX, int iDiffZ ) : Model( 0 ) {
	setShaderToUse( ShaderToUse::SOLID_COLOR_SHADER );
	bWind = false;
	fRotHeadStart = rand() % 20 + 1;
	setRotationAngle( fRotHeadStart );
	setRotationAxis( glm::vec3( 0, 0, 1 ) );
	float fRandomX = ( ( rand() % ( 10000 ) ) / 10000.0 ) * iDiffX + iX;
	float fRandomZ = ( ( rand() % ( 10000 ) ) / 10000.0 ) * iDiffZ + iZ;
	float fRandScX = ( rand() % 1000 ) / 1000.0;
	float fRandScY = ( rand() % 5000 ) / 10000.0 + 0.5;
	float fRandomGreen = ( rand() % 50 ) / 100.0 + 0.5;
	float fRandomRed = ( rand() % 50 ) / 100.0;
	float fAngle = ( rand() % 360 );
	float y = (ground->getHeight( fRandomX * fRandScX, fRandomZ ) / 15) + 16;
	glm::vec3 position = glm::vec3( fRandomX * fRandScX, y, fRandomZ );
	setPosition( position );
	glm::mat4 m = getRotationMatrix( fAngle, position );
	Vertex vertexBuffer[]  = {
		{ glm::vec3( m * glm::vec4( position,                                                         1 ) ), glm::vec3(0, 0, 0), glm::vec3( fRandomRed, fRandomGreen, 0) },
		{ glm::vec3( m * glm::vec4( fRandomX * fRandScX,        y,                   fRandomZ + 0.02, 1 ) ), glm::vec3(0, 0, 0), glm::vec3( fRandomRed, fRandomGreen, 0) },
		{ glm::vec3( m * glm::vec4( fRandomX * fRandScX + 0.08, y + 0.32 * fRandScY, fRandomZ,        1 ) ), glm::vec3(0, 0, 0), glm::vec3( fRandomRed, fRandomGreen, 0) },
		{ glm::vec3( m * glm::vec4( fRandomX * fRandScX + 0.08, y + 0.32 * fRandScY, fRandomZ + 0.02, 1 ) ), glm::vec3(0, 0, 0), glm::vec3( fRandomRed, fRandomGreen, 0) },
		{ glm::vec3( m * glm::vec4( fRandomX * fRandScX + 0.16, y + 0.56 * fRandScY, fRandomZ,        1 ) ), glm::vec3(0, 0, 0), glm::vec3( fRandomRed, fRandomGreen, 0) },
		{ glm::vec3( m * glm::vec4( fRandomX * fRandScX + 0.16, y + 0.56 * fRandScY, fRandomZ + 0.01, 1 ) ), glm::vec3(0, 0, 0), glm::vec3( fRandomRed, fRandomGreen, 0) },
		{ glm::vec3( m * glm::vec4( fRandomX * fRandScX + 0.24, y + 0.72 * fRandScY, fRandomZ,        1 ) ), glm::vec3(0, 0, 0), glm::vec3( fRandomRed, fRandomGreen, 0) },
		{ glm::vec3( m * glm::vec4( fRandomX * fRandScX + 0.24, y + 0.72 * fRandScY, fRandomZ + 0.01, 1 ) ), glm::vec3(0, 0, 0), glm::vec3( fRandomRed, fRandomGreen, 0) },
		{ glm::vec3( m * glm::vec4( fRandomX * fRandScX + 0.48, y + 0.96 * fRandScY, fRandomZ,        1 ) ), glm::vec3(0, 0, 0), glm::vec3( fRandomRed, fRandomGreen, 0) }
	};
	glGenVertexArrays(1, &vertexArrayID);
	glGenBuffers(1, &vertexBufferID);
	glBindBuffer(GL_ARRAY_BUFFER, vertexBufferID);
	glBufferData(GL_ARRAY_BUFFER, 9*sizeof(Vertex), vertexBuffer, GL_STATIC_DRAW);
}

GrassModel::~GrassModel() {}

glm::mat4 GrassModel::getRotationMatrix( float fAngle, glm::vec3 v ) {
	glm::mat4 m( 1.0f );
	m = glm::translate( m, v );
	m = glm::rotate( m, fAngle, glm::vec3( 0, 1, 0 ) );
	m = glm::translate( m, -v );
	return m;
}

void GrassModel::update( float dt ) {
	float fAngle = getRotationAngle();
	if( bWind ) {
		if( fAngle < 60 ) {
			setRotationAngle( fAngle + dt * fAngle );
		} else {
			setRotationAngle( fAngle - dt * 20 );
		}
	} else {
		if( fAngle > 20 + fRotHeadStart ) {
			setRotationAngle( fAngle - dt * 20 );
		} else if( fAngle > fRotHeadStart ) {
			setRotationAngle( fAngle - dt );
		}
	}
}

void GrassModel::draw() {

	glm::mat4 m = glm::mat4( 1.0f );
	m = glm::translate( m, getPosition() );
	m = glm::rotate( m, getRotationAngle(), glm::vec3( 0, 0, 1 ) );
	m = glm::translate( m, -getPosition() );
	
	glBindVertexArray(vertexArrayID);

	GLuint WorldMatrixLocation = glGetUniformLocation(Renderer::getShader(), "WorldTransform"); 
	glUniformMatrix4fv(WorldMatrixLocation, 1, GL_FALSE, &m[0][0]);

	// 1st attribute buffer : vertex Positions
	glEnableVertexAttribArray(0);
	glBindBuffer(GL_ARRAY_BUFFER, vertexBufferID);
	glVertexAttribPointer(0, 3,	GL_FLOAT, GL_FALSE,	sizeof(Vertex), (void*)0);

	// 2nd attribute buffer : vertex normal
	glEnableVertexAttribArray(1);
	glBindBuffer(GL_ARRAY_BUFFER, vertexBufferID);
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex), (void*)sizeof(glm::vec3));


	// 3rd attribute buffer : vertex color
	glEnableVertexAttribArray(2);
	glBindBuffer(GL_ARRAY_BUFFER, vertexBufferID);
	glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex), (void*)(2 * sizeof(glm::vec3)));

	// Draw the triangles !
	glDrawArrays(GL_TRIANGLE_STRIP, 0, 9);

	glDisableVertexAttribArray(2);
	glDisableVertexAttribArray(1);
	glDisableVertexAttribArray(0);
}
