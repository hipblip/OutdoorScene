/*
	Ancestor class for all models.  Uses an enumerated type to specify the shader to use when drawing the models.  Also holds the world matrix
	information: position, rotation, and scaling.  This class is also set up to support hierarchical modeling.

	Author(s): Samuel Desranleau, RJ Brack, Corneliu Dabija
*/

#pragma once

#include <GLM/glm.hpp>
#include "OBJLoader.h"
#include "ParsingHelper.h"
#include <vector>

enum class ShaderToUse {IMPORTED_MODEL_SHADER = 0, SOLID_COLOR_SHADER = 1, GROUND_SHADER = 2, SHADER_PARTICLE = 3, SKYBOX = 4};

class Model {
public:
	
 

	Model(Model *parent);
	Model();
	virtual ~Model();

	virtual void update(float dt) = 0;
	virtual void draw() = 0;

	void setPosition(glm::vec3 pos) { mPosition = pos; };
	void setScaling(glm::vec3 scale) { mScaling = scale; };
	void setRotationAxis(glm::vec3 axis) { mRotationAxis = axis; };
	void setRotationAngle(float angle) {mRotationAngle = angle; };

	float getRotationAngle() { return mRotationAngle; };

	glm::vec3 getPosition() { return mPosition; };

	glm::mat4 getWorldMatrix();

	virtual ShaderToUse getShaderToUse() { return shader; };

	void Load(ci_istringstream& iss);

	void wind( bool b );

protected:
	void setShaderToUse(ShaderToUse shade) { shader = shade; };

	bool bWind;
	
private:
	ci_string mName;

	glm::vec3 mPosition;
	glm::vec3 mScaling;
	glm::vec3 mRotationAxis;
	float     mRotationAngle;

	ShaderToUse shader;

	Model* parent;
	//OBJLoader* importedModel; // Only used if the model is imported
};