/*
	Header file for the grass generator.

	Author(s): Corneliu Dabija
*/

#pragma once

#include <vector>
#include "GrassModel.h"
#include "Ground.h"

using std::vector;

class GrassGenerator {

public:
	GrassGenerator( Ground * ground );
	~GrassGenerator();
	vector<Model *> getGrass();

private:
	Ground * gro;
};
