//
// COMP 371 Assignment Framework
//
// Created by Nicolas Bergeron on 8/7/14.
//
// Copyright (c) 2014 Concordia University. All rights reserved.
//
// Modifications done by: David Paparo

#pragma once

#include <GLM/glm.hpp>
#include "Ground.h"

class Ground;

class Camera
{
public:
	Camera(Ground* inGround);
	virtual ~Camera();

	virtual void Update(float dt) = 0;

	virtual glm::mat4 GetViewMatrix() const = 0;
	virtual glm::mat4 GetProjectionMatrix() const;
	glm::mat4 GetViewProjectionMatrix() const;

	virtual glm::vec3 GetLookAt() const = 0;
	virtual glm::vec3 GetPosition() const = 0;
protected:
	Ground* terrain;
};
