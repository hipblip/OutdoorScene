/*
	Provides an access point.

	Author(s): Samuel Desranleau
*/

#include "EventManager.h"
#include "Renderer.h"
#include "World.h"

int main() {
	EventManager::setUp();
	Renderer::setUp();

	World world;

	do { // Main Loop
		EventManager::update();
		Renderer::beginFrame();

		world.update(EventManager::GetFrameTime());
		world.draw();

		Renderer::endFrame();

	}while(EventManager::exitLoop() == false);

	EventManager::terminateProgram();
	Renderer::terminateProgram();
	return 0;
}