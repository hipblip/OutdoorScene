#pragma once

#include "GrassGenerator.h"
#include "Ground.h"
#include<ctime>

GrassGenerator::GrassGenerator( Ground * ground ) {
	srand(time(0));
	gro = ground;
}

GrassGenerator::~GrassGenerator() {}

vector<GrassModel> GrassGenerator::getGrass() {
	vector<GrassModel> grass;
	for( int j = 0; j < 5; j++ ) {
		grass.push_back( GrassModel( gro, 0, 0, 10, 10 ) );
	}
	return grass;
}