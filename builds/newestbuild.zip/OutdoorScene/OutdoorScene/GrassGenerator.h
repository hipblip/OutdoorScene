#pragma once

#include <vector>
#include "GrassModel.h"
#include "Ground.h"

using std::vector;

class GrassGenerator {

public:
	GrassGenerator( Ground * ground );
	~GrassGenerator();
	vector<GrassModel> getGrass();

private:
	Ground * gro;
};
