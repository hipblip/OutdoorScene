#pragma once

#include <GL/glew.h>
#include <GLFW/glfw3.h>
#include <glm/gtc/matrix_transform.hpp>

#include "GrassModel.h"
#include "Renderer.h"

using namespace std;

GrassModel::GrassModel( Ground * ground, int iX, int iZ, int iDiffX, int iDiffZ ) {
	bWind = false;
	mRotationAngleInDegrees = rand() % 20 + 1;
	fRotHeadStart = mRotationAngleInDegrees;
	float fRandomX = ( rand() % ( iDiffX * 10000 ) ) / 10000.0 + iX;
	float fRandomZ = ( rand() % ( iDiffZ * 10000 ) ) / 10000.0 + iZ;
	float fRandScX = ( rand() % 1000 ) / 50000.0;
	float fRandScY = ( rand() % 5000 ) / 20000.0 + 0.5;
	float fRandomGreen = ( rand() % 50 ) / 100.0 + 0.5;
	float fRandomRed = ( rand() % 50 ) / 100.0;
	float fAngle = ( rand() % 360 );
	position = glm::vec3( fRandomX * fRandScX, ground->getHeight( fRandomX * fRandScX, fRandomZ ), fRandomZ );
	glm::mat4 m = getRotationMatrix( fAngle, position );
	Vertex vertexBuffer[]  = {
		{ glm::vec3( m * glm::vec4( position,                                                                                                                        1 ) ), glm::vec3(0, 0, 0), glm::vec3(fRandomRed, fRandomGreen, 0) },
		{ glm::vec3( m * glm::vec4( fRandomX * fRandScX,        ground->getHeight( fRandomX * fRandScX, fRandomZ + 0.02 ),                          fRandomZ + 0.0002, 1 ) ), glm::vec3(0, 0, 0), glm::vec3(fRandomRed, fRandomGreen, 0) },
		{ glm::vec3( m * glm::vec4( fRandomX * fRandScX + 0.0008, ground->getHeight( fRandomX * fRandScX + 0.04, fRandomZ ) + 0.32 * fRandScY,        fRandomZ,        1 ) ), glm::vec3(0, 0, 0), glm::vec3(fRandomRed, fRandomGreen, 0) },
		{ glm::vec3( m * glm::vec4( fRandomX * fRandScX + 0.0008, ground->getHeight( fRandomX * fRandScX + 0.04, fRandomZ + 0.02 ) + 0.32 * fRandScY, fRandomZ + 0.0002, 1 ) ), glm::vec3(0, 0, 0), glm::vec3(fRandomRed, fRandomGreen, 0) },
		{ glm::vec3( m * glm::vec4( fRandomX * fRandScX + 0.0016, ground->getHeight( fRandomX * fRandScX + 0.08, fRandomZ ) + 0.56 * fRandScY,        fRandomZ,        1 ) ), glm::vec3(0, 0, 0), glm::vec3(fRandomRed, fRandomGreen, 0) },
		{ glm::vec3( m * glm::vec4( fRandomX * fRandScX + 0.0016, ground->getHeight( fRandomX * fRandScX + 0.08, fRandomZ + 0.01 ) + 0.56 * fRandScY, fRandomZ + 0.0001, 1 ) ), glm::vec3(0, 0, 0), glm::vec3(fRandomRed, fRandomGreen, 0) },
		{ glm::vec3( m * glm::vec4( fRandomX * fRandScX + 0.0024, ground->getHeight( fRandomX * fRandScX + 0.12, fRandomZ ) + 0.72 * fRandScY,        fRandomZ,        1 ) ), glm::vec3(0, 0, 0), glm::vec3(fRandomRed, fRandomGreen, 0) },
		{ glm::vec3( m * glm::vec4( fRandomX * fRandScX + 0.0024, ground->getHeight( fRandomX * fRandScX + 0.12, fRandomZ + 0.01 ) + 0.72 * fRandScY, fRandomZ + 0.0001, 1 ) ), glm::vec3(0, 0, 0), glm::vec3(fRandomRed, fRandomGreen, 0) },
		{ glm::vec3( m * glm::vec4( fRandomX * fRandScX + 0.0048, ground->getHeight( fRandomX * fRandScX + 0.24, fRandomZ ) + 0.96 * fRandScY,        fRandomZ,        1 ) ), glm::vec3(0, 0, 0), glm::vec3(fRandomRed, fRandomGreen, 0) }
	};
	glGenBuffers(1, &vertexBufferID);
	glBindBuffer(GL_ARRAY_BUFFER, vertexBufferID);
	glBufferData(GL_ARRAY_BUFFER, 9*sizeof(Vertex), vertexBuffer, GL_STATIC_DRAW);
}

GrassModel::~GrassModel() {}

glm::mat4 GrassModel::getRotationMatrix( float fAngle, glm::vec3 v ) {
	glm::mat4 m( 1.0f );
	m = glm::translate( m, v );
	m = glm::rotate( m, fAngle, glm::vec3( 0, 1, 0 ) );
	m = glm::translate( m, -v );
	return m;
}

void GrassModel::Update( float dt ) {
	if( bWind ) {
		if( mRotationAngleInDegrees < 60 ) {
			mRotationAngleInDegrees += dt * mRotationAngleInDegrees;
		} else {
			mRotationAngleInDegrees -= dt * 20;
		}
	} else {
		if( mRotationAngleInDegrees > 20 + fRotHeadStart ) {
			mRotationAngleInDegrees -= dt * 20;
		} else if( mRotationAngleInDegrees > fRotHeadStart ) {
			mRotationAngleInDegrees -= dt;
		}
	}
}

int GrassModel::getRandomSign() {
	return rand() % 2 == 1 ? 1 : -1;
}

glm::mat4 GrassModel::GetWorldMatrix() const {
	glm::mat4 worldMatrix( 1.0f );
	worldMatrix = glm::translate( worldMatrix, position );
	worldMatrix = glm::rotate( worldMatrix, mRotationAngleInDegrees, glm::vec3( 0, 0, 1 ) );
	worldMatrix = glm::translate( worldMatrix, -position );
	return worldMatrix;
}

void GrassModel::wind( bool b ) {
	bWind = b;
}

void GrassModel::Draw() {
	//GLuint WorldMatrixLocation = glGetUniformLocation(Renderer::getShader(), "WorldTransform"); 
	//glUniformMatrix4fv(WorldMatrixLocation, 1, GL_FALSE, &GetWorldMatrix()[0][0]);

	// 1st attribute buffer : vertex Positions
	glEnableVertexAttribArray(0);
	glBindBuffer(GL_ARRAY_BUFFER, vertexBufferID);
	glVertexAttribPointer(0, 3,	GL_FLOAT, GL_FALSE,	sizeof(Vertex), (void*)0);

	// 2nd attribute buffer : vertex normal
	glEnableVertexAttribArray(1);
	glBindBuffer(GL_ARRAY_BUFFER, vertexBufferID);
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex), (void*)sizeof(glm::vec3));


	// 3rd attribute buffer : vertex color
	glEnableVertexAttribArray(2);
	glBindBuffer(GL_ARRAY_BUFFER, vertexBufferID);
	glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex), (void*)(2 * sizeof(glm::vec3)));

	// Draw the triangles !
	glDrawArrays(GL_TRIANGLE_STRIP, 0, 9);

	glDisableVertexAttribArray(2);
	glDisableVertexAttribArray(1);
	glDisableVertexAttribArray(0);
}
