#include "OBJLoader.h"
#include "Renderer.h"

OBJLoader::OBJLoader(const char* filename) {
	position = glm::vec3(0,0,0);
	scaling = glm::vec3(1,1,1);
	rotationAxis = glm::vec3(1,0,0);
	rotationAngle = 0;

	Assimp::Importer importer;
	//Initialize DevIL
	devilStartUp(); 
	
	const aiScene* scene=importer.ReadFile(filename, aiProcess_GenSmoothNormals|aiProcess_Triangulate|aiProcess_CalcTangentSpace|aiProcess_FlipUVs);

	if(scene->mFlags==AI_SCENE_FLAGS_INCOMPLETE || !scene->mRootNode) 
	{ 
      fprintf( stderr, "Couldn't load model, Error Importing Asset" );	   
	  return;
	} 

	recursiveProcess(scene->mRootNode, scene);
}

OBJLoader::~OBJLoader()
{
	for(std::size_t i=0; i<meshes.size(); i++)
		delete meshes[i];
}

/* Initializes the third party softwares
 * @param void
 * @return void
 */
void OBJLoader::devilStartUp() {
	ilutRenderer(ILUT_OPENGL);
	ilInit();
	iluInit();
	ilutInit();
	ilutRenderer(ILUT_OPENGL);
}

/* Recursively processes the meshes of the model
 */
void OBJLoader::recursiveProcess(aiNode* node, const aiScene* scene) {
	//process
	for(std::size_t i=0; i<node->mNumMeshes;i++)
	{
		aiMesh* mesh = scene->mMeshes[node->mMeshes[i]];
		processMesh(mesh, scene);
	}

	//recursion
	for(std::size_t i=0; i<node->mNumChildren; i++)
	{
		recursiveProcess(node->mChildren[i], scene);
	}
}

/* Processes the mesh information
 */
void OBJLoader::processMesh(aiMesh* cmesh, const aiScene* scene) {
	vector<vertexData> data;
	vector<unsigned int> indices;
	vector<textureData> textures;
	aiColor4D col;
	aiMaterial* mat = scene->mMaterials[cmesh->mMaterialIndex];
	aiGetMaterialColor(mat, AI_MATKEY_COLOR_DIFFUSE, &col); 
	glm::vec3 defaultColor(col.r, col.g, col.b);

	for(std::size_t i=0; i<cmesh->mNumVertices; i++)
	{
		vertexData tmp;
		
		//position
		tmp.position = glm::vec3(cmesh->mVertices[i].x,  cmesh->mVertices[i].y, cmesh->mVertices[i].z);
		
		//normals
		tmp.normal = glm::vec3(cmesh->mNormals[i].x,  cmesh->mNormals[i].y, cmesh->mNormals[i].z);

		//tangents
		if(cmesh->mTangents)
			tmp.tangent = glm::vec3(cmesh->mTangents[i].x,  cmesh->mTangents[i].y, cmesh->mTangents[i].z);
		else
			tmp.tangent = glm::vec3(1,0,0);

		//colors
		if(cmesh->mColors[0])
			tmp.color = glm::vec3(cmesh->mColors[0][i].r,  cmesh->mColors[0][i].g, cmesh->mColors[0][i].b);
		else
			tmp.color = defaultColor;

		//UVs
		if(cmesh->mTextureCoords[0])
			tmp.UV = glm::vec2(cmesh->mTextureCoords[0][i].x,  cmesh->mTextureCoords[0][i].y);
		else
			tmp.UV = glm::vec2(0,0);
		data.push_back(tmp);
	}

	for(std::size_t i=0; i<cmesh->mNumFaces; i++)
	{
		aiFace face = cmesh->mFaces[i];
		for(std::size_t j=0; j<face.mNumIndices;j++) //0...2
		{
			indices.push_back(face.mIndices[j]);
		}
	}

	//handle textures
	for(std::size_t i=0; i<mat->GetTextureCount(aiTextureType_DIFFUSE); i++)
	{
		aiString str;
		mat->GetTexture(aiTextureType_DIFFUSE, i, &str);
		textureData tmp;
		tmp.id = loadTexture(str.C_Str());
		tmp.type = 0;	//Index for Diffuse Map
		textures.push_back(tmp);
	}

	meshes.push_back(new mesh(&data, &indices, &textures));
}

/* This function is used by loadTexture(const char* filename) to get the filepath
 * @param The name of the file
 * @return the path to the file
 */
string filepath(const char* filename) {
	string file = filename;
	string path;
	if (file.compare("wolf") == 0) {
		path = "Models/wolf/" + file;
	}

	return path;
}

/* This function loads the texture information from the model file
 * @param the name of the model file
 * @return the textureID
 */
unsigned int OBJLoader::loadTexture(const char* filename) {
	ILuint imageID;				// Create an image ID as a ULuint
 
	GLuint textureID;			// Create a texture ID as a GLuint
 
	ILboolean success;			// Create a flag to keep track of success/failure
 
	ILenum error;				// Create a flag to keep track of the IL error state
 
	ilGenImages(1, &imageID); 		// Generate the image ID
 
	ilBindImage(imageID); 			// Bind the image
 
	std::stringstream sstm;
	
	string fn = filename;

	std::cout << filename << endl;
	// Load image from file into filename
	if(fn.compare("ohniste4UVcomplet1.png") == 0)
		sstm << "Models/freplace/" << filename;
	else if (fn.compare("house.jpg") == 0)
		sstm << "Models/house/" << filename;

	success = ilLoadImage((const ILstring) &sstm.str()[0]); 	// Load the image file
 
	// If we managed to load the image, then we can start to do things with it...
	if (success)
	{
		// If the image is flipped (i.e. upside-down and mirrored, flip it the right way up!)
	/*	ILinfo ImageInfo;
		iluGetImageInfo(&ImageInfo);
		if (ImageInfo.Origin == IL_ORIGIN_UPPER_LEFT)
		{
			iluFlipImage();
		}*/

		// Convert the image into a suitable format to work with
		// NOTE: If your image contains alpha channel you can replace IL_RGB with IL_RGBA
		success = ilConvertImage(IL_RGB, IL_UNSIGNED_BYTE);
 
		// Quit out if we failed the conversion
		if (!success)
		{
			error = ilGetError();
			std::cout << "Image conversion failed - IL reports error: " << error << " - " << iluErrorString(error) << std::endl;
			exit(-1);
		}
 
		// Generate a new texture
		glGenTextures(1, &textureID);
 
		// Bind the texture to a name
		glBindTexture(GL_TEXTURE_2D, textureID);
 
		// Set texture clamping method
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);
 
		// Set texture interpolation method to use linear interpolation (no MIPMAPS)
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
 
		// Specify the texture specification
		glTexImage2D(GL_TEXTURE_2D, 				// Type of texture
					 0,				// Pyramid level (for mip-mapping) - 0 is the top level
					 ilGetInteger(IL_IMAGE_FORMAT),	// Internal pixel format to use. Can be a generic type like GL_RGB or GL_RGBA, or a sized type
					 ilGetInteger(IL_IMAGE_WIDTH),	// Image width
					 ilGetInteger(IL_IMAGE_HEIGHT),	// Image height
					 0,				// Border width in pixels (can either be 1 or 0)
					 ilGetInteger(IL_IMAGE_FORMAT),	// Format of image pixel data
					 GL_UNSIGNED_BYTE,		// Image data type
					 ilGetData());			// The actual image data itself
 	}
  	else // If we failed to open the image file in the first place...
  	{
		error = ilGetError();
		std::cout << "Image load failed - IL reports error: " << error << " - " << iluErrorString(error) << std::endl;
		exit(-1);
  	}
 
 	ilDeleteImages(1, &imageID); // Because we have already copied image data into texture data we can release memory used by image.
 
	std::cout << "Texture creation successful." << std::endl;
 
	return textureID; // Return the GLuint to the texture so you can use it!
}

glm::mat4 OBJLoader::getWorldMatrix() {
	glm::mat4 positionMat = glm::translate(glm::mat4(1.f), position);
	glm::mat4 scalingMat = glm::scale(glm::mat4(1.f), scaling);
	glm::mat4 rotationMat = glm::rotate(glm::mat4(1.f), rotationAngle, rotationAxis);

	glm::mat4 worldMatrix = positionMat * rotationMat * scalingMat;
	return worldMatrix;
}

/* Draws the model
 * @param the shader's ProgramID
 * @return void
 */
void OBJLoader::draw()
{
	GLuint worldID = glGetUniformLocation(Renderer::getShader(), "WorldMatrix");

	glUniformMatrix4fv(worldID, 1, GL_FALSE, &getWorldMatrix()[0][0]);


	for(std::size_t i=0; i<meshes.size();i++)
		meshes[i]->draw();
}

/* Simple getter function for the mesh vector
 * @param void
 * @return a reference to the vector of meshes
 */
vector<mesh*>& OBJLoader::getMeshes()
{
	return meshes;
}