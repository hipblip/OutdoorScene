//DANIEL MILLER

#include "Lightning.h"
#include "Renderer.h"
#include <glm/gtc/matrix_transform.hpp>
#include <glm/common.hpp>
#include <GL/glew.h>
#include <time.h>


using namespace std;
//using namespace glm;


//function to determine if we will add or subtract
float willAdd(float x)
{
	//somehow it looks better when the function always yields an addition.
		return (rand()%2==0) ? x : -x;
}


Lightning::Lightning(glm::vec3 &start, glm::vec3 &end, int noise, float width, glm::vec3 color, glm::vec3 direction)
	: Model(NULL), startPt(start), endPt(end), noise(noise), width(width), direction(direction)
{
	setShaderToUse(ShaderToUse::SOLID_COLOR_SHADER);
	branchCount++;
	setColor(color);
	glm::vec3 newPoint;
	glm::vec3 branchLine = glm::cross(direction, glm::vec3(0,1,0));
	
	//points.push_back(startPt);

	//srand(time(NULL));
	newPoint = startPt;
	while(points.size() <= 50)
	{
		newPoint.y -= ((rand() % 4)+1);
		int dx = (rand() % (noise))*branchLine.x;
		newPoint.x += willAdd(dx);
		int dz = (rand() % (noise))*branchLine.z;
		newPoint.z += willAdd(dz);
		points.push_back(newPoint);
	}
	
	
	Vertex vertexBuffer[50];
	
	int itVal = 0;
	//int size = points.size();
	for (vector<glm::vec3>::iterator it = points.begin();itVal<50 && itVal<points.size(); it++, itVal++)
	{
		Vertex v = {*it ,glm::vec3(0.f,0.f,0.f), color};
		vertexBuffer[itVal] = v;

		//Max 20 branches
		if (branchCount < 20)
		{
			tryToBranch(*it, endPt);
		}
	}

		// Create a vertex array
	glGenVertexArrays(1, &mVertexArrayID);
	

	// Upload Vertex Buffer to the GPU, keep a reference to it (mVertexBufferID)
	glGenBuffers(1, &mVertexBufferID);
	glBindBuffer(GL_ARRAY_BUFFER, mVertexBufferID);
	glBufferData(GL_ARRAY_BUFFER, sizeof(vertexBuffer), vertexBuffer, GL_STATIC_DRAW);
	allBranches.push_back(this);
}

Lightning::~Lightning()
{
	branchCount = 0;
	allBranches.clear();
}

void Lightning::setStart(glm::vec3 &v)
{
	startPt = v;
}

void Lightning::setEnd(glm::vec3 &v)
{
	endPt = v;
}

glm::vec3 Lightning::getStart()
{
	return startPt;
}

glm::vec3 Lightning::getEnd()
{
	return endPt;
}

vector<glm::vec3> Lightning::getPoints()
{
	return points;
}

void Lightning::setColor(glm::vec3 v)
{
	color = v;
}

void Lightning::draw()
{
	// Draw the Vertex Buffer
	// Note this draws a unit Cube
	// The Model View Projection transforms are computed in the Vertex Shader
	glBindVertexArray(mVertexArrayID);

	GLuint WorldMatrixLocation = glGetUniformLocation(Renderer::getShader(), "WorldTransform"); 
	glUniformMatrix4fv(WorldMatrixLocation, 1, GL_FALSE, &getWorldMatrix()[0][0]);
	
	glLineWidth(width);
	
	// 1st attribute buffer : vertex Positions
	glEnableVertexAttribArray(0);
	glBindBuffer(GL_ARRAY_BUFFER, mVertexBufferID);
	glVertexAttribPointer(	0,				// attribute. No particular reason for 0, but must match the layout in the shader.
							3,				// size
							GL_FLOAT,		// type
							GL_FALSE,		// normalized?
							sizeof(Vertex), // stride
							(void*)0        // array buffer offset
						);

	// 2nd attribute buffer : vertex normal
	glEnableVertexAttribArray(1);
	glBindBuffer(GL_ARRAY_BUFFER, mVertexBufferID);
	glVertexAttribPointer(	1,
							3,
							GL_FLOAT,
							GL_FALSE,
							sizeof(Vertex),
							(void*)sizeof(glm::vec3)    // Normal is Offseted by vec3 (see class Vertex)
						);


	// 3rd attribute buffer : vertex color
	glEnableVertexAttribArray(2);
	glBindBuffer(GL_ARRAY_BUFFER, mVertexBufferID);
	glVertexAttribPointer(	2,
							3,
							GL_FLOAT,
							GL_FALSE,
							sizeof(Vertex),
							(void*) (2* sizeof(glm::vec3)) // Color is Offseted by 2 vec3 (see class Vertex)
						);

	glDrawArrays(GL_LINE_STRIP, 0, points.size()/3); 

	glDisableVertexAttribArray(2);
	glDisableVertexAttribArray(1);
	glDisableVertexAttribArray(0);
}

void Lightning::update(float dt)
{
	//Do nothing
}

std::vector<Lightning*> Lightning::getAllBranches()
{
	return Lightning::allBranches;
}

void Lightning::tryToBranch(glm::vec3 &start, glm::vec3 &end)
{
	//start is branch point.
	//end is end point of main branch
	if (rand()%20 == 1)
	{
		//start = glm::vec3(GetWorldMatrix()*glm::vec4(start,1));
		//end = glm::vec3(GetWorldMatrix()*glm::vec4(end,1));
		Lightning* branch = new Lightning(start, end, noise, width/2.f, color, direction);
	}
}

std::vector<Lightning*> Lightning::allBranches;
int Lightning:: branchCount = 0;