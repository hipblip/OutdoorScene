#pragma once

#include <vector>
#include <glm/glm.hpp>
#include <GL/glew.h>
#include "Ground.h"

class GrassModel {

public:
	GrassModel( Ground * ground, int iX = -5, int iZ = -5, int iDiffX = 10, int iDiffZ = 10 );
	virtual ~GrassModel();
	virtual glm::mat4 GetWorldMatrix() const;
	virtual void Update( float dt );
	virtual void Draw();
	void wind( bool b );

private:
	int getRandomSign();
	glm::mat4 getRotationMatrix( float fAngle, glm::vec3 v );
	GLuint vertexBufferID;
	float mRotationAngleInDegrees;
	glm::vec3 position;
	bool bWind;
	float fRotHeadStart;
};

struct Vertex {
	glm::vec3 position;
	glm::vec3 normal;
	glm::vec3 color;
};